import socket
import netifaces as ni
import csv
import os
import sys
import traceback
import time
from fcf import *
import pickle


array=ni.interfaces()
print "array",array[1]
ni.ifaddresses(array[1])
ip = ni.ifaddresses(array[1])[2][0]['addr']
print "ip of me",type(ip)

f1=open('reachability.txt','r')
reach=f1.read().split('\n')
print reach
list_fcf_to_pass=[]

if os.path.isfile("status_frame.txt"):
	print "Is there"

	print "Im in prep_fcf"
with open('status_frame.txt','rb') as f:
	contents=f.read().split('\n')
	for i in range(0,len(contents)-1):
		full_field=contents[i]
		print "entry in file",full_field
		status=contents[i].split(',')
		print "Status",status[1]
		if (int(status[1])==1):
			print "One faulty node found...putting into fcf"
			for field in range(0,len(reach)-1):
				ipaddr_and_count=reach[field]
				count=ipaddr_and_count.split(',')
				print "count:",count[0]
				if (count[0]==status[0]):
					 print "Same IP"
					 print "Iterator field",field
					 ip_of_faulty = count[0]
					 print "Faulty cha IP",ip_of_faulty
					 reach_of_faulty = count[1]
					 print "Faulty cha reachability",reach_of_faulty
					 vote=1
					 from_ip=ip
					 fcf_1=fcf(ip_of_faulty,reach_of_faulty,vote,from_ip)
					 final_fcf=fcf_1.__dict__
					 print "fcf",final_fcf
					 list_fcf_to_pass.append(final_fcf)
					 


print "List fcf",list_fcf_to_pass

maxi=0
prev_max=maxi   #5

port = 20220
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
f3=open("reachability.txt","r")
count1=f3.read().split('\n')
print "file contents",count1
for i in range(0,len(count1)-1):
	#print i
	count2=count1[i].split(',')
	if(int(count2[1]) > maxi):
		maxi=int(count2[1])
		ipofmax=count2[0]
		
	print "count2",int(count2[1])
print "ipofmax",ipofmax
print "Max Reachability",maxi
f3.close()

compare_string=str(ipofmax)+","+str(maxi)

print "compare_string",compare_string
with open("reachability.txt","r+") as f4:
	count4=f4.read().split('\n')
	f4.seek(0)
	for line in count4:
		
		line=str(line)
		print "LINE",line
		print "Line type",type(line)
		print "comp_string type",type(compare_string)
		if compare_string ==line:
			print "In if"
		else:
			print "In else"
			f4.write(line)
			f4.write('\n')
		
	f4.truncate()

f4.close()
print "maximum count is",maxi


visited = []




host=str(ipofmax)
strr=pickle.dumps(list_fcf_to_pass)
s.sendto(strr,(host,port))
print "sent"


'''for i in range(0,len(list_fcf_to_pass)):
    lst_field=list_fcf_to_pass[i]
    for key in lst_field:
	if(key=='vote'and lst_field['ip']=='192.168.1.103'):
	    dicti=list_fcf_to_pass[i]
	    val=dicti[key]
	    print "Vote value",val
	    val=val+1
	    dicti[key]=val
	    list_fcf_to_pass[i]=dicti'''

#print list_fcf_to_pass
	    

#f=fcf(ip,rch,vote) 

