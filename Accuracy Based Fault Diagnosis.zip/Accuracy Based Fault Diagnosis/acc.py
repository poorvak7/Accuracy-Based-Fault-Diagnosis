import socket
import netifaces as ni
import csv
import os
import sys
import traceback
import time
from cmpself_test import * 


array=ni.interfaces()
print "array",array[1]
ni.ifaddresses(array[1])
ip = ni.ifaddresses(array[1])[2][0]['addr']
print "ip of me",type(ip)

with open('neighbours.txt')as f:
	count=sum(1 for _ in f)
print "My reachability is :",count		#self node's reachability is obtained
f.close()





maxi=count
ipofmax=''
f3=open("reachability.txt","r")
count1=f3.read().split('\n')
print "file contents",count1
for i in range(0,len(count1)-1):
	#print i
	count2=count1[i].split(',')
	if(int(count2[1]) > maxi):
		maxi=int(count2[1])
		ipofmax=count2[0]
	print "count2",int(count2[1])
print "ipofmax",type(ipofmax)
print "maximum count is",maxi
f3.close()


ip=str(ip)

if(ip == ipofmax and status==0 ):
	print "I have the max reachability count..switch control to fcf"
	f2=open("status_frame.txt","w")
port = 20222
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)


with open('neighbours.txt')as f1:
	line=f1.read().split('\n')
	print line

print "My status is:",status
for i in range(0,len(line)-1):
	host = line[i]
	print "Entry in file",host

	addr=(host,port)
	print "Address",addr
	
	msg="Send your status"
	s.sendto(msg,addr)

	print "Receiving neighbour's status"

	nstat,naddr=s.recvfrom(1024)
	print "Received status from neighbour",nstat
	f2.write(addr[0])
	f2.write(",")
	f2.write(nstat)
	f2.write("\n")
	f2.close()

	f1.close()
	os.system("python prep_fcf.py")



else:
	print "Receiving mode"
	print "Switching to backrecv"
	os.system("python backrecv.py")



