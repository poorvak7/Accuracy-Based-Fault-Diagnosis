import socket
import netifaces as ni
import csv
import os
import sys
import traceback
import time
import socket,pickle
from fcf import *
from  cmpself_test import *

s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
port = 20222
host =''
s.bind((host,port))
buf,addr=s.recvfrom(1024)
print "Received msg",buf


f_reach=open("reachability.txt","rb")
#--------------------------------------------------------------------------------
print "My status is:",status
s.sendto(str(status),addr)
#-------------------------Getting FCF because I have next highest reachability ------------------------------------------

fcf1,addr=s.recvfrom(1024)
print "fcf",fcf1

if(fcf=="Send your Status"):
	s.sendto(str(status),addr)

else:
	fcf_unpacked=pickle.loads(fcf1)
	print "fcf_unpacked",fcf_unpacked

#---------------------------Asking neighbours to send their status-----------------------------------------------------

	print "I am next highest reachability. Now receiving my neighbours' status"

	with open('neighbours.txt')as f1:
		line=f1.read().split('\n')
		print line


	f2=open("status_frame.txt","w")

	for i in range(0,len(line)-1):
		host = line[i]
		print "Entry in file",host

		addr=(host,port)
		print "Address",addr
	
		msg="Send your status"
		time.sleep(2)
		s.sendto(msg,addr)

	#-----------------------Getting status from neighbours---------------------------------------------------------

		print "Receiving neighbour's status"
		nstat,naddr=s.recvfrom(1024)
		print "Received status from neighbour",nstat
		f2.write(addr[0])
		f2.write(",")
		f2.write(nstat)
		f2.write("\n")
	f2.close()
	f1.close()

	#-------------------------------------Add your faulty nodes to FCF----------------------------------------------
	with open('tp.txt','rb') as f:
		contents=f.read().split('\n')
		for i in range(0,len(contents)-1):
			full_field=contents[i]
			print "entry in file",full_field
			status1=contents[i].split(',')
			print "Status",status1[1]
			if (int(status1[1])==1):
				print "One faulty node found...putting into fcf"
				print "Full Status1 field",status1


				for i in range(0,len(fcf_unpacked)):
				    lst_field=fcf_unpacked[i]
				    field_in_fcf=(lst_field['ip'],lst_field['rch'])
				    hi=if any(str(field_in_fcf) in s for s in reach)

				    
                                    print "hi",hi

                                    print "field_in_fcf",field_in_fcf
				    

				    for key in lst_field:
					if(key=='vote'and hi):
					    dicti=fcf_unpacked[i]
					    val=dicti[key]
					    print "Vote value",val
					    val=val+1
					    dicti[key]=val
					    fcf_unpacked[i]=dicti
		
	#-------------------------------First time entry in the FCF-------------------------------------------------------
					
					
					else:
					    contents=f.read().split('\n')
					    for i in range(0,len(contents)-1):
					        full_field=contents[i]
						print "entry in file",full_field
						status1=contents[i].split(',')
						print "Status1:",status1[1]
						if (int(status1[1])==1):
							print "One faulty node found...putting into fcf"
							print "Full Status1 field",status1
							ip_of_faulty=status1[0]
							vote=1
							

							

						
							 

	print "fcf_unpacked_new",fcf_unpacked
