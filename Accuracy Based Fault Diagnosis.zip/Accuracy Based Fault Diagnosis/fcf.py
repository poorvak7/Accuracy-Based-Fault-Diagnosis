import netifaces as ni


class fcf:
	def __init__(self,ip,rch,vote,from_ip):
		self.ip=ip
		self.rch=rch
		self.vote=vote
		self.from_ip=from_ip
		


