import csv

global arr
arr = []

a = 31
b = 10
l=4.5
m=8.5
c = 0
d=0
e=0
f=0
g=0

for i in range(8):
	arr.append(0)
c = a + b
arr[0]=c
d = a - b
arr[1]=d
e = a * b
arr[2]=e
f = a / b
arr[3]=f
g=a%10
arr[4]=g
i=a and b
arr[5]=i
j=a or b
arr[6]=j
k=l+m
arr[7]=k



#print "\n Result Array after self tests:",arr 

with open('resultarr.csv', 'w') as fp:
    a = csv.writer(fp, delimiter=',')
    a.writerow(arr)



